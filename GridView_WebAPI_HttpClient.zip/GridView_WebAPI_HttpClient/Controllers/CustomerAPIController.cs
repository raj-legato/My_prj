﻿using GridView_WebAPI_HttpClient.Models;
using System;
using System.Collections.Generic;
using System.Web.Http;
using System.Linq;

namespace GridView_WebAPI_HttpClient.Controllers
{
    public class CustomerAPIController : ApiController
    {
        [Route("api/CustomerAPI/GetCustomers")]
        [HttpPost]
        public List<Customer> GetCustomers(CustomerModel customer)
        {
            NorthwindEntities entities = new NorthwindEntities();
            return (from c in entities.Customers.Take(10)
                    where c.ContactName.StartsWith(customer.Name) || string.IsNullOrEmpty(customer.Name)
                    select c).ToList();
        }
    }
}
