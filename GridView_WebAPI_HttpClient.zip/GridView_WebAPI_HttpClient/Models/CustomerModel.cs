﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GridView_WebAPI_HttpClient.Models
{
    public class CustomerModel
    {
        /// <summary>
        /// Gets or sets Name.
        /// </summary>
        public string Name { get; set; }
    }
}